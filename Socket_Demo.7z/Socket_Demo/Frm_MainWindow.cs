﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Socket_Demo
{
    public partial class Frm_MainWindow : Form
    {
        public Frm_MainWindow()
        {
            InitializeComponent();
        }

        /*
         服务端程序的编写步骤
         1、调用socket()函数创建一个用于通信的套接字
         2、给以创建的套接字绑定一个端口号，这一般通过设置网络套接字地址和嗲用bind()函数来实现
         3、调用listen()函数使套接字成为一个监听套接字
         4、调用accept(0函数来接收客户端的连接，这时就可以和客户端通信了
         5、处理客户端的连接请求
         6、终止连接

         如果服务器有4个客户端连接，
         服务端有多少个socket存在            5
         每个客户端有多少个socket存在        1  
         */


        private Socket listenSocket;

        // 字典集合 存储IP和Socket的集合
        private Dictionary<string, Socket> OnLineList = new Dictionary<string, Socket>();
        /// <summary>
        /// 当前时间
        /// </summary>
        private string CurrentTime
        {
            get { return DateTime.Now.ToString("HH:mm:ss") + Environment.NewLine; }
        }

        Encoding enconding = Encoding.Default;

        private void btn_StartServer_Click(object sender, EventArgs e)
        {
            // 调用socket()函数创建一个用于通信的套接字
            listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            // 给以创建的套接字绑定一个端口号，这一般通过设置网络套接字地址和嗲用bind()函数来实现
            IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(this.tb_IPAddress.Text.Trim()), int.Parse(this.tb_Port.Text.Trim()));

            try
            {
                listenSocket.Bind(endPoint);
            }
            catch (Exception ex)
            {

                tb_Receive.AppendText("服务器开启失败:" + ex.Message);
                return;
            }
            
            
            // 调用listen()函数使套接字成为一个监听套接字
            listenSocket.Listen(10);        // 10表示最大允许10个客户端连接到服务器
            ShowMessage("服务器开启成功");
            // 开启一个线程来监听
            Task.Run(new Action(() =>
            {
                ListenConnection();
            }));
            this.btn_StartServer.Enabled = false;
        }

        //
        private void ListenConnection()
        {
            while(true)
            {
                
                Socket clientSocket = listenSocket.Accept();
                string ip = clientSocket.RemoteEndPoint.ToString();
                // 更新在线列表
                UpdateOnline(ip, true);
                // 更新在线列表集合
                OnLineList.Add(ip, clientSocket);
                ShowMessage(ip + "上线了");

                Task.Run(() => ReceiveMsg(clientSocket));
            }
        }

        /// <summary>
        /// 接收方法
        /// </summary>
        /// <param name="clientSocket"></param>
        private void ReceiveMsg(Socket clientSocket)
        {
            while(true)
            {
                byte[] buffer = new byte[2024 * 2024];
                int length = -1;
                try
                {
                    length = clientSocket.Receive(buffer);
                }
                catch (Exception)
                {

                    // 客户端下线
                    // 更新在线列表
                    string ip = clientSocket.RemoteEndPoint.ToString();
                    UpdateOnline(ip, false);

                    OnLineList.Remove(ip);
                    break;
                }
                if (length == 0)
                {
                    // 客户端下线
                    // 更新在线列表
                    string ip = clientSocket.RemoteEndPoint.ToString();
                    UpdateOnline(ip, false);

                    OnLineList.Remove(ip);
                    ShowMessage(ip + "已下线");
                    break;
                }

                if(length > 0)
                {
                    string info = enconding.GetString(buffer, 0, length);
                    ShowMessage(info);
                }
            }
        }

        /// <summary>
        /// 更新在线列表
        /// </summary>
        /// <param name="clientIp"></param>
        /// <param name="value"></param>
        private void UpdateOnline(string clientIp, bool value)
        {
            Invoke(new Action(() =>
            {
                if (value)
                {
                    list_Online.Items.Add(clientIp);
                }
                else
                {
                    list_Online.Items.Remove(clientIp);
                }
            }));
            
        }
        /// <summary>
        /// 更新在线列表
        /// </summary>
        /// <param name="clientIp"></param>
        /// <param name="value"></param>
        private void ShowMessage(string info)
        {
            Invoke(new Action(() =>
            {
                tb_Receive.AppendText(CurrentTime + info + Environment.NewLine);
            }));

        }

        /// <summary>
        /// 客户端但发数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_SendData_Click(object sender, EventArgs e)
        {
            if (list_Online.SelectedIndex != -1)
            {
                foreach (string item in list_Online.SelectedItems)
                {
                    if(OnLineList.ContainsKey(item))
                    {
                        OnLineList[item].Send(enconding.GetBytes(tb_Send.Text.Trim()));
                    }
                }
            }
            else
            {
                if (list_Online.Items.Count == 0)
                {
                    ShowMessage("当前无客户端连接");

                }
                else
                {
                    ShowMessage("请选择要发送的对象");
                }

            }
        }
        /// <summary>
        /// 服务端群发数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_SendAll_Click(object sender, EventArgs e)
        {
            
            foreach (string item in list_Online.Items)
            {
                if (OnLineList.ContainsKey(item))
                {
                    OnLineList[item].Send(enconding.GetBytes(tb_Send.Text.Trim()));
                }
            }
            
            
        }
    }
}
