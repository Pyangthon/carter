﻿namespace Socket_Demo
{
    partial class Frm_MainWindow
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_IPAddress = new System.Windows.Forms.TextBox();
            this.tb_Port = new System.Windows.Forms.TextBox();
            this.btn_StartServer = new System.Windows.Forms.Button();
            this.tb_Receive = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_Send = new System.Windows.Forms.TextBox();
            this.btn_SendData = new System.Windows.Forms.Button();
            this.btn_SendAll = new System.Windows.Forms.Button();
            this.list_Online = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(610, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "IP地址：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(610, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "端口号：";
            // 
            // tb_IPAddress
            // 
            this.tb_IPAddress.Location = new System.Drawing.Point(669, 86);
            this.tb_IPAddress.Name = "tb_IPAddress";
            this.tb_IPAddress.ReadOnly = true;
            this.tb_IPAddress.Size = new System.Drawing.Size(100, 21);
            this.tb_IPAddress.TabIndex = 2;
            this.tb_IPAddress.Text = "127.0.0.1";
            // 
            // tb_Port
            // 
            this.tb_Port.Location = new System.Drawing.Point(669, 135);
            this.tb_Port.Name = "tb_Port";
            this.tb_Port.Size = new System.Drawing.Size(100, 21);
            this.tb_Port.TabIndex = 2;
            this.tb_Port.Text = "8080";
            // 
            // btn_StartServer
            // 
            this.btn_StartServer.Location = new System.Drawing.Point(612, 391);
            this.btn_StartServer.Name = "btn_StartServer";
            this.btn_StartServer.Size = new System.Drawing.Size(75, 23);
            this.btn_StartServer.TabIndex = 3;
            this.btn_StartServer.Text = "启动服务";
            this.btn_StartServer.UseVisualStyleBackColor = true;
            this.btn_StartServer.Click += new System.EventHandler(this.btn_StartServer_Click);
            // 
            // tb_Receive
            // 
            this.tb_Receive.Location = new System.Drawing.Point(12, 26);
            this.tb_Receive.Multiline = true;
            this.tb_Receive.Name = "tb_Receive";
            this.tb_Receive.Size = new System.Drawing.Size(581, 335);
            this.tb_Receive.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "消息接收区";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 377);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "消息接收区";
            // 
            // tb_Send
            // 
            this.tb_Send.Location = new System.Drawing.Point(12, 403);
            this.tb_Send.Multiline = true;
            this.tb_Send.Name = "tb_Send";
            this.tb_Send.Size = new System.Drawing.Size(581, 70);
            this.tb_Send.TabIndex = 5;
            // 
            // btn_SendData
            // 
            this.btn_SendData.Location = new System.Drawing.Point(612, 436);
            this.btn_SendData.Name = "btn_SendData";
            this.btn_SendData.Size = new System.Drawing.Size(75, 23);
            this.btn_SendData.TabIndex = 3;
            this.btn_SendData.Text = "发送消息";
            this.btn_SendData.UseVisualStyleBackColor = true;
            this.btn_SendData.Click += new System.EventHandler(this.btn_SendData_Click);
            // 
            // btn_SendAll
            // 
            this.btn_SendAll.Location = new System.Drawing.Point(713, 436);
            this.btn_SendAll.Name = "btn_SendAll";
            this.btn_SendAll.Size = new System.Drawing.Size(75, 23);
            this.btn_SendAll.TabIndex = 3;
            this.btn_SendAll.Text = "群发消息";
            this.btn_SendAll.UseVisualStyleBackColor = true;
            this.btn_SendAll.Click += new System.EventHandler(this.btn_SendAll_Click);
            // 
            // list_Online
            // 
            this.list_Online.FormattingEnabled = true;
            this.list_Online.ItemHeight = 12;
            this.list_Online.Location = new System.Drawing.Point(612, 204);
            this.list_Online.Name = "list_Online";
            this.list_Online.Size = new System.Drawing.Size(157, 160);
            this.list_Online.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(610, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 1;
            this.label5.Text = "在线列表";
            // 
            // Frm_MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 512);
            this.Controls.Add(this.list_Online);
            this.Controls.Add(this.tb_Send);
            this.Controls.Add(this.tb_Receive);
            this.Controls.Add(this.btn_SendAll);
            this.Controls.Add(this.btn_SendData);
            this.Controls.Add(this.btn_StartServer);
            this.Controls.Add(this.tb_Port);
            this.Controls.Add(this.tb_IPAddress);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Frm_MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_IPAddress;
        private System.Windows.Forms.TextBox tb_Port;
        private System.Windows.Forms.Button btn_StartServer;
        private System.Windows.Forms.TextBox tb_Receive;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_Send;
        private System.Windows.Forms.Button btn_SendData;
        private System.Windows.Forms.Button btn_SendAll;
        private System.Windows.Forms.ListBox list_Online;
        private System.Windows.Forms.Label label5;
    }
}

